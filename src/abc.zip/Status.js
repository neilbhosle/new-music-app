// Status.js
// import React, { useState } from 'react';

// const Status = () => {
//     const [status, setStatus] = useState('');

//     return (
//         <div>
//             <p>Status: {status}</p>
//         </div>
//     );
// };

// export default Status;

// import React from 'react';

// const Status = ({ isPlaying, currentSelection, isFirstPlay }) => {
//     let isMusicTrack = currentSelection.hasOwnProperty('title');

//     return (
//         <div>
//             <p>Status: 
//                 {!isPlaying && !isMusicTrack && isFirstPlay && ''}    
//                 {isPlaying && <span>{isMusicTrack ? currentSelection.title : currentSelection.episodeTitle}</span>} 
//                 {!isPlaying && !isFirstPlay && 'Paused'}
//                 {console.log('isPlaying: ', isPlaying)} 
//                 {console.log('isMusicTrack: ', isMusicTrack)}
//                 {console.log('currentSelection: ', currentSelection)}
//                 {console.log('isFirstPlay: ', isFirstPlay)}
//             </p>
//         </div>
//     );
// };

// export default Status;

// import React from 'react';

// const Status = ({ isPlaying, currentSelection, isInitial }) => {
//     let isMusicTrack = currentSelection.hasOwnProperty('title');

//     return (
//         <div>
//             <p>Status: 
//                 {!isPlaying && !isMusicTrack && isInitial && ''}    
//                 {isPlaying && <span>{isMusicTrack ? currentSelection.title : currentSelection.episodeTitle}</span>} 
//                 {!isPlaying && !isInitial && 'Paused'}
//                 {console.log('isPlaying: ', isPlaying)} 
//                 {console.log('isMusicTrack: ', isMusicTrack)}
//                 {console.log('currentSelection: ', currentSelection)}
//                 {console.log('isInitial: ', isInitial)}
//             </p>
//         </div>
//     );
// };

// export default Status;

// import React from 'react';

// const Status = ({ isPlaying, currentSelection, isInitial }) => {
//     let isMusicTrack = currentSelection.hasOwnProperty('title');

//     return (
//         <div>
//             <p>Status: 
//                 {isPlaying ? 
//                     (isMusicTrack ? 
//                         currentSelection.title : 
//                         currentSelection.episodeTitle
//                     ) :
//                     (isInitial ? '' : 'Paused')
//                 }
//             </p>
//         </div>
//     );
// };

// export default Status;

// import React from 'react';

// const Status = ({ isPlaying, currentSelection }) => {
//     let isMusicTrack = currentSelection.hasOwnProperty('title');

//     return (
//         <div>
//             <p>Status: 
//                 {isPlaying ? 
//                     (isMusicTrack ? 
//                         currentSelection.title : 
//                         currentSelection.episodeTitle
//                     ) :
//                     'Paused'
//                 }
//             </p>
//         </div>
//     );
// };

// export default Status;


import React from 'react';

const Status = ({ isPlaying, currentSelection }) => {
    let isMusicTrack = currentSelection.hasOwnProperty('title');

    return (
        <div>
            <p>Status: 
                {isPlaying ?
                    (isMusicTrack ?
                        currentSelection.title :
                        currentSelection.episodeTitle
                    ) :
                    (currentSelection ? 'Paused' : '')
                }
            </p>
        </div>
    );
};

export default Status;

// import React from 'react';

// const Status = ({ isPlaying, currentSelection }) => {
//     let isMusicTrack = currentSelection && currentSelection.hasOwnProperty('title');

//     return (
//         <div>
//             <p>Status: 
//                 {isPlaying ?
//                     (isMusicTrack ?
//                         currentSelection.title :
//                         currentSelection.episodeTitle
//                     ) :
//                     ''
//                 }
//             </p>
//         </div>
//     );
// };

// export default Status;
