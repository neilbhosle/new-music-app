

// import React from 'react';
// import './style.css'; 

// const Song = ({ song }) => {
//     const { title, artist, year } = song;

//     return (
//         <div className="entry-container song-container">
//             <h2 className="title">{title}</h2>
//             <p className="artist">Artist: {artist}</p>
//             {year && <p className="details">Year: {year}</p>}
//         </div>
//     );
// };

// export default Song;

// Song.js
// import React from 'react';
// import './style.css'; 

// const Song = ({ song }) => {
//     const { title, artist, year } = song;

//     return (
//         <div className="entry-container song-container">
//             <h2 className="title">{title}</h2>
//             <p className="artist">Artist: {artist}</p>
//             {year && <p className="details">Year: {year}</p>}
//         </div>
//     );
// };

// export default Song;

import React from 'react';

// const Song = ({ title, artist, year, onTrackClick }) => {
//     return (
//         <div onDoubleClick={onTrackClick}>
//             <h2>Title: {title}</h2>
//             <p>Artist: {artist}</p>
//             <p>Year: {year}</p>
//         </div>
//     );
// };

// export default Song;


const Song = ({ title, artist, year, onItemClick }) => {
    return (
        <div onDoubleClick={onItemClick}>
            <h2>Title: {title}</h2>
            <p>Artist: {artist}</p>
            <p>Year: {year}</p>
        </div>
    );
};

export default Song;