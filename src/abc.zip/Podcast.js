

// import React from 'react';
// import './style.css'; 

// class Podcast extends React.Component {
//   render() {
    
//     const { podcast } = this.props;
//     const { season, episode, episodeTitle,title } = podcast;

//     return (
//       <div className="entry-container podcast-container">
//         <h2 className="title">{title}</h2>
//         {season !== undefined && episode !== undefined ? (
//           <p className="details">Season {season} Episode {episode}</p>
//         ) : (
//           <p className="details">Episode {episode}</p>
//         )}
//         {episodeTitle && <p className="episode-title">Episode Title: {episodeTitle}</p>}
//       </div>
//     );
//   }
// }

// export default Podcast;

// Podcast.js
// import React from 'react';
// import './style.css'; 

// const Podcast = ({ podcast }) => {
//     const { title, host, season, episode, episodeTitle } = podcast;

//     return (
//         <div className="entry-container podcast-container">
//             <h2 className="title">{title}</h2>
//             {season !== undefined && episode !== undefined ? (
//                 <p className="details">Season {season} Episode {episode}</p>
//             ) : (
//                 <p className="details">Episode {episode}</p>
//             )}
//             {episodeTitle && <p className="episode-title">Episode Title: {episodeTitle}</p>}
//             <p className="host">Host: {host}</p>
//         </div>
//     );
// };

// export default Podcast;


import React from 'react';

// const Podcast = ({ episodeTitle, episode, season, onEpisodeClick }) => {
//     return (
//         <div onDoubleClick={onEpisodeClick}>
//             <h3>{episodeTitle}</h3>
//             {episode && <p>Episode: {episode}</p>}
//             {season && <p>Season: {season}</p>}
//         </div>
//     );
// };

// export default Podcast;

const Podcast = ({ episodeTitle, episode, season, onItemClick }) => {
    return (
        <div onDoubleClick={onItemClick}>
            <h3>{episodeTitle}</h3>
            {episode && <p>Episode: {episode}</p>}
            {season && <p>Season: {season}</p>}
        </div>
    );
};

export default Podcast;