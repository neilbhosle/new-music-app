
// import React, { useEffect, useState } from 'react';
// import Song from './Song';
// import Podcast from './Podcast';
// import './style.css';

// const Playlist = ({ playlistData }) => {
//     const [shuffledPlaylist, setShuffledPlaylist] = useState([]);

//     // Function to shuffle the playlist data
//     const shufflePlaylist = (data) => {
//         const shuffledData = [...data];
//         for (let i = shuffledData.length - 1; i > 0; i--) {
//             const j = Math.floor(Math.random() * (i + 1));
//             [shuffledData[i], shuffledData[j]] = [shuffledData[j], shuffledData[i]];
//         }
//         return shuffledData;
//     };

//     const handleShuffle = () => {
       
//         setShuffledPlaylist(shufflePlaylist(playlistData));
//     };

//     useEffect(() => {
        
//         setShuffledPlaylist(shufflePlaylist(playlistData));
//     }, [playlistData]);

//     const renderSongs = () => (
//         <div>
//             <h2>Songs</h2>
//             {shuffledPlaylist
//                 .filter((item) => item.type === 'song')
//                 .map((song) => (
//                     <Song key={song.id} song={song} />
//                 ))}
//         </div>
//     );

//     const renderPodcasts = () => (
//         <div>
//             <h2>Podcasts</h2>
//             {shuffledPlaylist
//                 .filter((item) => item.type === 'podcast')
//                 .map((podcast) => (
//                     <Podcast key={podcast.id} podcast={podcast} />
//                 ))}
//         </div>
//     );

//     return (
//         <div>
//             <button className="outlined-dark-button" onClick={handleShuffle}>Shuffle Playlist</button>
//             {renderSongs()}
//             {renderPodcasts()}
//         </div>
//     );
// };

// export default Playlist;


// Playlist.js
// import React, { useState, useEffect } from 'react';
// import Song from './Song';
// import Podcast from './Podcast';
// import ControlButtons from './ControlButtons';
// import Status from './Status';
// import './style.css';

// const Playlist = () => {
//     const [playlistData, setPlaylistData] = useState([]);

//     useEffect(() => {
//         fetch('http://localhost:3000/playlist')
//             .then(response => response.json())
//             .then(data => setPlaylistData(data))
//             .catch(error => console.error('Error fetching data:', error));
//     }, []);

//     return (
//         <div>
//             <Status />
//             <ControlButtons />
//             <div>
//                 <h2>Songs</h2>
//                 {playlistData
//                     .filter(item => item.type === 'song')
//                     .map(song => <Song key={song.id} song={song} />)}
//             </div>
//             <div>
//                 <h2>Podcasts</h2>
//                 {playlistData
//                     .filter(item => item.type === 'podcast')
//                     .map(podcast => <Podcast key={podcast.id} podcast={podcast} />)}
//             </div>
//         </div>
//     );
// };

// export default Playlist;

// Playlist.js
// import React, { useState, useEffect } from 'react';
// import Song from './Song';
// import Podcast from './Podcast';
// import ControlButtons from './ControlButtons';
// import Status from './Status';
// import './style.css';

// const Playlist = () => {
//     const [playlistData, setPlaylistData] = useState([]);

//     useEffect(() => {
//         fetch('http://localhost:3000/playlist') // Update the fetch URL
//             .then(response => response.json())
//             .then(data => setPlaylistData(data.playlist)) // Accessing the 'playlist' key from the fetched data
//             .catch(error => console.error('Error fetching data:', error));
//     }, []);

//     return (
//         <div>
//             <Status />
//             <ControlButtons />
//             <div>
//                 <h2>Songs</h2>
//                 {playlistData
//                     .filter(item => item.title && item.artist && item.year) // Filtering songs based on available keys
//                     .map(song => <Song key={song.title} song={song} />)} {/* Assuming 'title' is unique */}
//             </div>
//             <div>
//                 <h2>Podcasts</h2>
//                 {playlistData
//                     .filter(item => item.podcast || item.episodeTitle) // Filtering podcasts based on available keys
//                     .map(podcast => <Podcast key={podcast.episodeTitle} podcast={podcast} />)} {/* Assuming 'episodeTitle' is unique */}
//             </div>
//         </div>
//     );
// };

// export default Playlist;

// import React, { useState, useEffect } from 'react';
// import Song from './Song';
// import Podcast from './Podcast';
// import ControlButtons from './ControlButtons';
// import Status from './Status';
// import './style.css';

// const Playlist = () => {
//     const [playlistData, setPlaylistData] = useState([]);

//     useEffect(() => {
//         fetch('http://localhost:3000/playlist')
//             .then(response => response.json())
//             .then(data => setPlaylistData(data.playlist))
//             .catch(error => console.error('Error fetching data:', error));
//     }, []);

//     return (
//         <div>
//             <Status />
//             <ControlButtons />
//             <div>
//                 <h2>Songs</h2>
//                 {playlistData && playlistData.length > 0 &&
//                     playlistData
//                         .filter(item => item.title && item.artist && item.year)
//                         .map(song => <Song key={song.title} song={song} />)}
//             </div>
//             <div>
//                 <h2>Podcasts</h2>
//                 {playlistData && playlistData.length > 0 &&
//                     playlistData
//                         .filter(item => item.podcast || item.episodeTitle)
//                         .map(podcast => <Podcast key={podcast.episodeTitle} podcast={podcast} />)}
//             </div>
//         </div>
//     );
// };

// export default Playlist;

// import React, { useState, useEffect } from 'react';
// import Song from './Song';
// import Podcast from './Podcast';
// import ControlButtons from './ControlButtons';
// import Status from './Status';
// import './style.css';

// const Playlist = () => {
//     const [playlistData, setPlaylistData] = useState([]);

//     useEffect(() => {
//         fetch('http://localhost:3000/playlist')
//             .then(response => response.json())
//             .then(data => setPlaylistData(data.playlist))
//             .catch(error => console.error('Error fetching data:', error));
//     }, []);

//     return (
//         <div>
//             <Status />
//             <ControlButtons />
//             <div>
//                 <h2>Songs</h2>
//                 {playlistData && playlistData.length > 0 &&
//                     playlistData
//                         .filter(item => item.title && item.artist) // Only check for title and artist
//                         .map(song => <Song key={song.title} song={song} />)}
//             </div>
//             <div>
//                 <h2>Podcasts</h2>
//                 {playlistData && playlistData.length > 0 &&
//                     playlistData
//                         .filter(item => item.podcast || item.episodeTitle) // Only check for podcast or episodeTitle
//                         .map(podcast => <Podcast key={podcast.episodeTitle} podcast={podcast} />)}
//             </div>
//         </div>
//     );
// };

// export default Playlist;


// Playlist.js
// import React, { useState, useEffect } from 'react';
// import Song from './Song';
// import Podcast from './Podcast';
// import ControlButtons from './ControlButtons';
// import Status from './Status';
// import './style.css';

// const Playlist = () => {
//     const [playlistData, setPlaylistData] = useState([]);

//     useEffect(() => {
//         fetch('http://localhost:3001/playlist')
//             .then(response => response.json())
//             .then(data => {
//                 console.log('Fetched data:', data.playlist);
//                 setPlaylistData(data.playlist);
//             })
//             .catch(error => console.error('Error fetching data:', error));
//     }, []);
    

//     return (
//         <div>
//             <Status />
//             <ControlButtons />
//             <div>
//                 <h2>Songs</h2>
//                 {playlistData && playlistData.length > 0 &&
//                     playlistData
//                         .filter(item => item.title && item.artist && item.year && !item.episode && !item.season)
//                         .map(song => <Song key={song.title} song={song} />)}
//             </div>
//             <div>
//                 <h2>Podcasts</h2>
//                 {playlistData && playlistData.length > 0 &&
//                     playlistData
//                         .filter(item => (item.podcast || item.episodeTitle) && (!item.title || !item.artist || !item.year))
//                         .map(podcast => <Podcast key={podcast.episodeTitle} podcast={podcast} />)}
//             </div>
//         </div>
//     );
// };

// export default Playlist;


import React, { useEffect, useState } from 'react';
import Song from './Song';
import Podcast from './Podcast';
import Status from './Status';

const Playlist = () => {
    // const [currentSelection, setCurrentSelection] = useState(undefined);
    const [tracksData, setTracksData] = useState([]);
    const [currentTracks, setCurrentTracks] = useState([]);
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentSelection, setCurrentSelection] = useState({});
    const [isInitial, setIsInitial] = useState(true);

    useEffect(() => {
        fetch('http://localhost:3001/tracks')
            .then(response => response.json())
            .then(data => {
                console.log('Fetched data:', data);
                setTracksData(data);
                updateTracks(data);
            })
            .catch(error => console.error('Error fetching data:', error));
    }, []);

    console.log(currentSelection);

    function updateTracks(newTracks) {
        let updatedTracks = newTracks.map((track, index) => {
            return {
                ...track,
                id: index
            };
        });
        setCurrentTracks(updatedTracks);
    }

    function shuffleTracks() {
        let shuffledTracks = [...currentTracks].sort(() => Math.random() - 0.5);
        setIsPlaying(false);
        setCurrentTracks(shuffledTracks);
        setCurrentSelection({});
        setIsInitial(true);
    }

    function playPreviousTrack() {
        let newIndex = currentTracks.findIndex((track) => track.id === currentSelection.id);
        newIndex -= 1;
        if (newIndex < 0) {
            newIndex = 0;
        }
        let newTrack = currentTracks[newIndex];
        setIsPlaying(true);
        setCurrentSelection(newTrack);
    }

    function playNextTrack() {
        let newIndex = currentTracks.findIndex((track) => track.id === currentSelection.id);
        newIndex += 1;
        if (newIndex >= currentTracks.length) {
            newIndex = currentTracks.length - 1;
        }
        let newTrack = currentTracks[newIndex];
        setIsPlaying(true);
        setCurrentSelection(newTrack);
    }

    function handleTrackClick(track, index) {
        setIsInitial(false);
        setIsPlaying(true);
        setCurrentSelection(track);
    }

    function togglePlayPause() {
        setIsPlaying(!isPlaying);
    }

    return (
        <div>
            <h2>Playlist</h2>
            {currentTracks.length > 0 ? (
                currentTracks.map((track, index) => {
                    if (track.title && track.artist && track.year) {
                        return (
                            <Song
                                key={index}
                                title={track.title}
                                artist={track.artist}
                                year={track.year}
                                onItemClick={() => handleTrackClick(track, index)} // Changed prop name
                            />

                        );
                    } else if (track.episodeTitle) {
                        return (
                            <Podcast
                                key={index}
                                episodeTitle={track.episodeTitle}
                                episode={track.episode}
                                onItemClick={() => handleTrackClick(track, index)}
                            />
                            

                            
                        );
                    } else {
                        return null;
                    }
                })
            ) : (
                <p>No items in the playlist</p>
            )}
            <div>
                <button onClick={playPreviousTrack}>Prev</button>
                <button onClick={togglePlayPause}>Play/Pause</button>
                <button onClick={playNextTrack}>Next</button>
                <button onClick={shuffleTracks}>Shuffle</button>
            </div>
            {/* <Status status={isPlaying} currentSelection={currentSelection} isInitial={isInitial} /> */}
            <Status isPlaying={isPlaying} currentSelection={currentSelection} isInitial={isInitial} />

        </div>
    );
};

export default Playlist;
